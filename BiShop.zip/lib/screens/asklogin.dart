import 'package:flutter/material.dart';

class AskLogin extends StatelessWidget {
  const AskLogin({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('You are not logged in'),
          const SizedBox(height: 20),
          ElevatedButton( 
            onPressed: () {
              Navigator.pushNamed(context, '/login');
            },
            child: const Text('Login'),
          ),
        ],
      ),
    );
  }
}
